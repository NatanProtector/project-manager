Distributed systems homework 3

About:
A project information managment system

to start:
npm install; npm start